#include "ProcInfo/procinfo.h"

using std::string;
using procinfo::env_from_pid;
using procinfo::path_from_pid;
using procinfo::pid_from_self;

int main(int argc, char **argv) {
  string path = path_from_pid(pid_from_self());
  if (argc == 2) {
    printf("%s", env_from_pid(stoul(string(argv[1]), nullptr, 10)).c_str());
    printf("%s", "\r\n");
  } else {
    printf("%s", "usage: ");
    if (string_has_whitespace(path)) {
      printf("%s", "\"");
    }
    if (string_has_whitespace(path)) {
      printf("%s", string_replace_all(path, "\"", "\\\"").c_str());
    } else {
      printf("%s", path.c_str());
    }
    if (string_has_whitespace(path)) {
      printf("%s", "\"");
    }
    printf("%s", " <pid>");
    printf("%s", "\r\n");
  }
  return 0;
}