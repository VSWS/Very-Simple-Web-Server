#include "getprocinfo32.h"
#include "getprocinfo64.h"
